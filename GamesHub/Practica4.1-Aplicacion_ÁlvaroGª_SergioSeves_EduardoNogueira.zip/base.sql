




Table Categorias{
  ID integer [primary key]
  Nombre varchar
}

Table Claves{
  ID integer [primary key]
  clave varchar
  id_producto integer [ref: > Productos.ID]
}

Table Productos{
  ID integer [primary key]
  precio float
  Categoria integer [ref: > Categorias.ID]
  Descripcion longtext
  Nombre varchar
}

Table Ususarios{
  ID integer [primary key]
  Name varchar
  Correo varchar
  Rol integer
  Passwd varchar
  Puntos integer
}

Table Compras{
  ID integer [primary key]
  User integer [ref: > Ususarios.ID]
  fecha date
}

Table compras_productos{
  ID integer [primary key]
  N_compras integer [ref: > Compras.ID]
  N_productos integer [ref: > Productos.ID]
  Unidades integer
}



